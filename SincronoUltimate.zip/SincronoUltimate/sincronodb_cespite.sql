CREATE DATABASE  IF NOT EXISTS `sincronodb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
USE `sincronodb`;
-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: sincronodb
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cespite`
--

DROP TABLE IF EXISTS `cespite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `cespite` (
  `id_cespite` int(11) NOT NULL AUTO_INCREMENT,
  `descrizione` varchar(45) DEFAULT NULL,
  `stato` enum('Assegnato','Non Assegnato','Dismesso','Difettato') DEFAULT NULL,
  `tipologia` enum('Elettronico (generico)','Pc Desktop','Pc Laptop','Tablet','Tv/Monitor','Hardware Rete','Arredamento (generico)','Sedia','Scrivania','Armadio','Lavagna','Varie') DEFAULT NULL,
  PRIMARY KEY (`id_cespite`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cespite`
--

LOCK TABLES `cespite` WRITE;
/*!40000 ALTER TABLE `cespite` DISABLE KEYS */;
INSERT INTO `cespite` VALUES (1,'Thinkpad T470s ','Assegnato','Pc Laptop'),(2,'Thinkpad T470s ','Assegnato','Pc Laptop'),(3,'Thinkpad T470s ','Assegnato','Pc Laptop'),(4,'Thinkpad T470s ','Assegnato','Pc Laptop'),(5,'Dell XPS 9570','Assegnato','Pc Laptop'),(6,'Dell XPS 9570','Assegnato','Pc Laptop'),(7,'Sony Bravia kd55af9','Assegnato','Tv/Monitor'),(8,'Samsung 43nu7090','Assegnato','Tv/Monitor'),(9,'Ikea Malm','Assegnato','Scrivania'),(10,'Ikea Malm','Non Assegnato','Scrivania'),(11,'Sedia IMS','Assegnato','Sedia'),(12,'Sedia IMS','Assegnato','Sedia'),(13,'Ikea Adalrik','Assegnato','Armadio'),(14,'D-Link Des-105','Assegnato','Hardware Rete'),(15,'D-Link Des-105','Assegnato','Hardware Rete'),(16,'Amazon Basics','Assegnato','Lavagna'),(17,'Bose Lifestyle 550','Assegnato','Elettronico (generico)'),(18,'Philips Picopix I','Non Assegnato','Elettronico (generico)'),(19,'Dell Optiplex 3020m','Assegnato','Pc Desktop'),(20,'Dell Optiplex 3020m','Assegnato','Pc Desktop'),(21,'TP-Link Ripetitore TL-WA850RE','Non Assegnato','Hardware Rete'),(22,'Kubo II angolare','Assegnato','Scrivania'),(23,'Bi-Office Maya','Assegnato','Lavagna');
/*!40000 ALTER TABLE `cespite` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-25 14:41:07
