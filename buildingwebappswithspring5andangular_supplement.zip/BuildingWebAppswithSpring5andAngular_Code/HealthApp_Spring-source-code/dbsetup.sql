drop database if exists healthapp;
create database healthapp;
