describe('Hello World', function () {
    it('unit tests are good', function () { return expect(true).toBe(true); });
});
//# sourceMappingURL=helloworld.spec.js.map