import {Component} from '@angular/core';

@Component({
  template: `
  <div>You have just logged out!</div>
  `
})
export class LogoutComponent{}